package tools

type ToolResponse struct {
	Data            string
	DataDescription string
	ShowWay         string
}
