package dao

// 商品搜索。product表的字段有id、name、color、price、comment_num、is_deleted。只能选择未删除的商品即is_deleted=false的。分页查询,每页10个,每次只搜第一页。
