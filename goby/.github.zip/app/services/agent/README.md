代码有点问题，之后再调
main.gogogo是能用的