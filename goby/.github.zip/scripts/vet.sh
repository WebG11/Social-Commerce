# #!/bin/bash

# . scripts/list_mod.sh

# get_mod_list

# readonly root_path=${PWD}

# echo $MODULES
# for module in $MODULES; do
# echo "${root_path}/${module}"
#     go vet "${root_path}/${module}"
# done